// Coastline service worker: offline cache only. It must never rewrite game code.
// All runtime fixes live in game-v3.html and the scripts it loads, so the game behaves
// identically with or without this worker (itch.io, Cloudflare, Vercel, local server).
const CACHE_NAME='coastline-static-v48';
// The pinned Three.js build never changes for a given version, so cache it for offline play and to avoid re-downloads.
const CDN_PREFIX='https://cdn.jsdelivr.net/npm/three@0.170.0/';
const CDN_CACHE='coastline-cdn-v1';
const CORE=['./','./index.html','./game-v3.html','./vehicle-visual-enhancer.js','./cinematic-world-upgrade.js','./coastline-runtime-fix.js','./coastline-stability-v8.js','./car-customization.js','./world-model.js','./world-engine.js','./living-world.js','./douglassville-layout.js','./realism-library.js','./presentation-runtime.js','./replayability-engine.js','./npc-agency-engine.js','./npc-world-slice.js','./social-rumor-engine.js','./player-reputation-engine.js'];

self.addEventListener('install',event=>{
  // add() per file: one missing file must not discard the whole precache (cache.addAll is all-or-nothing).
  event.waitUntil(caches.open(CACHE_NAME)
    .then(cache=>Promise.allSettled(CORE.map(url=>cache.add(url))))
    .then(()=>self.skipWaiting()));
});

self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys()
    .then(keys=>Promise.all(keys.filter(key=>key!==CACHE_NAME&&key!==CDN_CACHE).map(key=>caches.delete(key))))
    .then(()=>self.clients.claim()));
});

// Network-first for same-origin GETs so HTML and JS modules never come from different releases;
// the cache is only the offline fallback.
self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET'||request.headers.has('range'))return;
  const url=new URL(request.url);
  if(request.url.startsWith(CDN_PREFIX)){
    event.respondWith(caches.open(CDN_CACHE).then(async cache=>{
      const hit=await cache.match(request);
      if(hit)return hit;
      const response=await fetch(request);
      if(response.ok&&response.type==='cors')cache.put(request,response.clone()).catch(()=>{});
      return response;
    }));
    return;
  }
  if(url.origin!==self.location.origin||url.pathname.startsWith('/api/'))return;
  event.respondWith(fetch(request).then(response=>{
    if(response.ok){const copy=response.clone();caches.open(CACHE_NAME).then(cache=>cache.put(request,copy)).catch(()=>{})}
    return response;
  }).catch(async()=>{
    const cached=await caches.match(request,{ignoreSearch:true});
    if(cached)return cached;
    if(request.mode==='navigate'){const entry=await caches.match('./index.html');if(entry)return entry}
    return Response.error();
  }));
});
