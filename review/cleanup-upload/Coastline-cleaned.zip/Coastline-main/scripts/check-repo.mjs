// Fast, dependency-free repository integrity checks (no browser needed). Run: npm run check
// Guards against the classes of drift that previously shipped silently:
//  - a service worker that rewrites game source (silent no-op replacements, different build per entry point)
//  - missing local files referenced by entry pages or the precache list
//  - modules that no longer parse
//  - workflows that can push to the default branch
import { readFileSync, readdirSync, existsSync, statSync, writeFileSync, rmSync } from 'node:fs';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const errors = [];
const fail = message => errors.push(message);
const read = file => readFileSync(path.join(root, file), 'utf8');

// 1. Every shipped script parses.
const scriptDirs = ['.', 'src', 'api', 'scripts', 'babylon'];
for (const dir of scriptDirs) {
  const abs = path.join(root, dir);
  if (!existsSync(abs)) continue;
  for (const name of readdirSync(abs)) {
    if (!/\.(js|mjs|cjs)$/.test(name)) continue;
    const file = path.join(abs, name);
    if (!statSync(file).isFile()) continue;
    try { execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' }); }
    catch (error) { fail(`${path.relative(root, file)} does not parse: ${String(error.stderr || error.message).split('\n')[0]}`); }
  }
}

// 2. Entry pages only reference files that exist.
const refPattern = /(?:src|href)=["'](\.\/[^"'?#]+)|(?:from\s*|import\s*\(?\s*)["'](\.\/[^"'?#]+)/g;
for (const page of ['index.html', 'game-v3.html', 'game-v2.html']) {
  if (!existsSync(path.join(root, page))) { fail(`missing entry page ${page}`); continue; }
  for (const match of read(page).matchAll(refPattern)) {
    const ref = match[1] || match[2];
    if (!existsSync(path.join(root, ref))) fail(`${page} references missing file ${ref}`);
  }
}
const required = ['coastline-runtime-fix.js', 'coastline-stability-v8.js', 'car-customization.js'];
for (const script of required) if (!read('game-v3.html').includes(script)) fail(`game-v3.html must load ${script} itself (the service worker no longer injects it)`);

// 3. Service worker: precache list exists and the worker never rewrites responses.
const sw = read('coastline-sw.js');
const core = sw.match(/const CORE=\[([^\]]*)\];/);
if (!core) fail('coastline-sw.js must declare `const CORE=[...];` on one line (scripts/build-itch.mjs rewrites it)');
else for (const match of core[1].matchAll(/'\.\/([^']*)'/g)) if (match[1] && !existsSync(path.join(root, match[1]))) fail(`service worker precaches missing file ./${match[1]}`);
if (!/const CACHE_NAME='coastline-static-v\d+';/.test(sw)) fail("coastline-sw.js must declare `const CACHE_NAME='coastline-static-vN';`");
if (/patchFullBetaHtml|new Response\(/.test(sw)) fail('the service worker must not rewrite game code; put fixes in game-v3.html or the scripts it loads');

// 3b. Everything the game can load (transitively) must be precached, so offline play and the itch package stay complete.
const localRefs = text => [...text.matchAll(/(?:from\s*|import\s*\(?\s*|src=)["'](\.\/[^"'?#]+)/g)].map(match => match[1].slice(2));
const reached = new Set();
const visit = file => {
  if (reached.has(file) || !existsSync(path.join(root, file))) return;
  reached.add(file);
  if (/\.(js|html)$/.test(file)) for (const ref of localRefs(read(file))) visit(ref);
};
for (const entry of ['game-v3.html', ...required]) visit(entry);
const precached = new Set(core ? [...core[1].matchAll(/'\.\/([^']*)'/g)].map(match => match[1]) : []);
for (const file of reached) if (!precached.has(file)) fail(`${file} is loaded by the game but missing from the service-worker CORE list`);

// 3c. The inline game module must parse (it is the largest file and has no other syntax check), and the
// service worker's CDN cache prefix must match the Three.js version the game imports.
const gameHtml = read('game-v3.html');
const inline = /<script type="module">([\s\S]*?)<\/script>/.exec(gameHtml);
if (!inline) fail('game-v3.html has no inline module script');
else {
  const tmp = path.join(os.tmpdir(), `coastline-inline-${process.pid}.mjs`);
  writeFileSync(tmp, inline[1]);
  try { execFileSync(process.execPath, ['--check', tmp], { stdio: 'pipe' }); }
  catch (error) { fail(`game-v3.html inline module does not parse: ${String(error.stderr || error.message).split('\n').slice(0, 5).join(' ')}`); }
  finally { rmSync(tmp, { force: true }); }
}
const threeVersion = /three@([0-9.]+)\/build\/three\.module\.js/.exec(gameHtml)?.[1];
if (!threeVersion || !sw.includes(`https://cdn.jsdelivr.net/npm/three@${threeVersion}/`)) fail('coastline-sw.js CDN_PREFIX must match the Three.js version imported by game-v3.html');

// 4. Only the reviewed workflows may hold contents:write (never push to the default branch).
const writers = new Set(['ai-continuous-dev.yml', 'coastline-ai-correction.yml']);
for (const name of readdirSync(path.join(root, '.github', 'workflows'))) {
  const text = read(path.join('.github', 'workflows', name));
  if (/contents:\s*write/.test(text) && !writers.has(name)) fail(`.github/workflows/${name} has contents: write; AGENTS.md forbids automation pushing to main`);
}

if (errors.length) {
  console.error('Repository integrity check failed:\n - ' + errors.join('\n - '));
  process.exit(1);
}
console.log('Repository integrity check passed.');
