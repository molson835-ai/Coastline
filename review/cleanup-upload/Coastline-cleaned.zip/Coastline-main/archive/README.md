# Archive

Unshipped prototypes kept for reference. Nothing here is loaded by the game, the service worker, the itch.io
package or CI, and they are excluded from static-asset deployment.

- `prototypes/coastline-cinematic*.html`, `coastline-visual.html`, `coastline-next-phase.html`: earlier cinematic and
  visual-pass pages. Their relative script paths assumed the repository root, so copy them back to the root to run them.
- `prototypes/coastline-ai-runtime.js`, `coastline-ai-worker.js`, `coastline-live-ops.js`: the optional AI/live-ops
  runtime described in `docs/COASTLINE_AI_RUNTIME_ARCHITECTURE.md`. Not wired into `game-v3.html`.

Anything deleted outright (versioned launcher stubs `game-v30`..`game-v35`, the second service worker, the
`coastline-visual-v3x.js` patch scripts) is recoverable from git history.
