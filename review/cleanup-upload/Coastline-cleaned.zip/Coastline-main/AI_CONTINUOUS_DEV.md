# Coastline AI Continuous Development (optional, disabled by default)

`.github/workflows/ai-continuous-dev.yml` can run an OpenAI Codex agent against this repository. It is
**manual-only** (`workflow_dispatch`): there is no schedule and no issue trigger.

## Cost and approval

The workflow needs an `OPENAI_API_KEY` repository secret. API usage can cost money, so under the free-only rule in
[AGENTS.md](AGENTS.md) it must not be enabled without an explicit owner decision. Leave the secret unset to keep
it inert. The shipped game never needs, contains, or receives an API key.

## What it does when run

- Reads the repository, recent work, open issues and pull requests, then follows `.github/AI_DEV_PROMPT.md`.
- Works on a feature branch and opens a pull request. It never merges, deploys, or pushes to `main`.
- Uploads a report artifact (`ai-dev-result.md`).

## Safety

`AGENTS.md` is the canonical policy; if the prompt and `AGENTS.md` ever disagree, `AGENTS.md` wins. Every
change still needs the normal checks (`npm run check` and the test suites) and human review.
