# Coastline

A browser-based, open-world coastal driving game. The world is generated in code (no paid assets) and rendered
in real time with [Three.js](https://threejs.org/) (pinned to r170, loaded from jsDelivr).

## Play

`index.html` is a launcher that opens `game-v3.html`, the actual game. `game-v2.html` is kept as a driving-focused
fallback/reference build.

Serve the folder with any static server (modules do not load from `file://`):

```bash
npm install
npm run serve          # http://127.0.0.1:4173
```

The game is static and can be hosted on GitHub Pages, Vercel, Cloudflare Workers assets, or packaged for itch.io
(`npm run package:itch` writes `dist/itch-html`). An internet connection is needed for the Three.js CDN files.

## Controls

- **W / S:** accelerate / brake and reverse
- **A / D:** steer left / right (turn left / right on foot)
- **E:** enter, exit or interact
- **Esc:** pause
- **Touch:** on-screen steering and pedal buttons

## What is in the build

Driving and walking, ambient traffic and pedestrians, vehicle damage and a garage, landmark discoveries and
replayable missions, a shared deterministic world model (`world-model.js`, `world-engine.js`), living-world, NPC,
rumor and reputation systems, day/night and weather, adaptive render quality, and an offline cache.

## Development

```bash
npm run check          # fast integrity checks: syntax, entry points, service-worker cache list, workflow rules
npm run test:engine    # deterministic world-engine unit tests (node)
npm run test:systems   # replayability, NPC, rumor, reputation unit tests (node)
npm run test:vehicle   # vehicle-dynamics unit test (node)
npm run test:gameplay  # Playwright browser tests (needs: npx playwright install chromium)
npm test               # everything above
```

Browser tests run headless with software rendering. They prove behavior, not frame rate, handling feel, or
real-phone performance; those still need human playtesting.

Rules for contributors and AI agents are in [AGENTS.md](AGENTS.md). Architecture notes live in [docs/](docs/)
(start with `docs/ARCHITECTURE_AUDIT.md` and `docs/COASTLINE_2_ARCHITECTURE.md`).

### Layout

- `game-v3.html`: the game (one large inline ES module; prefer isolated modules over editing it broadly)
- `*.js` at the root: modules and scripts loaded by the game (see `CORE` in `coastline-sw.js`)
- `coastline-sw.js`: offline cache only; it never modifies game code
- `src/`: vehicle-dynamics module (unit-tested, not yet wired into the game)
- `babylon/`: experimental Babylon.js engine track
- `api/`: optional serverless AI control plane; inert unless `COASTLINE_AI_CONTROL_TOKEN` is configured
- `archive/`: unshipped prototypes kept for reference

## Known limitations

- No `package-lock.json` yet. Run `npm install` once locally and commit the lockfile, then switch CI to `npm ci`.
- Vehicle handling is arcade-style and needs on-device tuning; performance targets are unmeasured on real phones.
- Two quality controllers (`game-v3.html` adaptive quality and `coastline-runtime-fix.js`) both manage render scale.
  They should be merged into one after profiling on real devices.
- The Coastline Transition Manager and first transition destination described in
  `docs/superpowers/specs/` are design-only; no implementation exists on `main`.
- `cinematic-*-library.js` are unit-tested but not loaded by the game yet.
