Upload the two .glb files in this folder to the Coastline repository folder assets/vehicles on branch coastline-authored-sedan-hatchback.
Expected exact filenames:
- white-four-door-sedan.glb
- blue-five-door-compact-hatchback.glb
Do not upload this ZIP itself as a model asset; extract it first and upload the two GLB files.
